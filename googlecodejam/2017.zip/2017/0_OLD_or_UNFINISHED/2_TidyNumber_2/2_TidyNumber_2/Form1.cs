﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_TidyNumber_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public string repeat(string input, int repeat)
        {
            string output = "";
            for (int i = 1; i <=repeat; i++)
            {
                output += input;
            }
            
            return output; 
        }


        public Int64 check(Int64 input)
        {
            Int64 output = input;
            int pos = 0;
            string temp = input.ToString();
            
            for (int i = 1; i < temp.Length; i++)
            {
                if (Convert.ToInt32(temp.Substring(i, 1)) < Convert.ToInt32(temp.Substring(i - 1, 1)))
                {
                    pos = i;
                    break;
                }               
            }
            string reBuild = ""; 
            for (int j = 0; j < pos; j++)
            {
                reBuild += temp.Substring(j, 1); 
            }

            reBuild += repeat("0", temp.Length - pos);

            output = Convert.ToInt64(reBuild);

            return output;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = check(7).ToString(); 
        }
    }
}
