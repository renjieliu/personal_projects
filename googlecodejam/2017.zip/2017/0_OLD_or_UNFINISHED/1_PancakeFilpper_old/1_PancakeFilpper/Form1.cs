﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections; 

namespace _1_PancakeFilpper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public string repeat(string input, int repeat)
        {

            string output = "";
            for (int i = 1; i <= repeat; i++)
            {
                output += input;
            }

            return output;
        }

        public ArrayList possible(int K)
        {
            ArrayList output = new ArrayList();

            for (int i = 1; i < K; i++)
            {
                output.Add(repeat("-", K - i) + repeat("+", i) + repeat("-", K - i)); 
            }
                        
            return output;
        }




        private void button1_Click(object sender, EventArgs e)
        {

            foreach (object o in possible(9))
            {
                richTextBox1.Text += o.ToString() + "\r\n";
            }
            
            string[] content = File.ReadAllLines(@"C:\Users\lrjthinkpad\Desktop\a.txt");
            string result = "";
            for (int line = 1; line < content.Count(); line++)
            {
                string input = content[line].Split(' ')[0].ToString();
                int K = Convert.ToInt32(content[line].Split(' ')[1]);

                string replace_1 = repeat("-", K);
                string replace_2 = "-" + repeat("+", K - 1) + "-";
                string replace_3 = repeat("+", K);
                

                int repeat_1_count = (input.Length - input.Replace(replace_1, "").Length) / K; //simple replace 

                string temp = input.Replace(replace_1, "");
                int repeat_2_count = 0; 
                foreach (object o in possible(K))
                {
                    if (temp.IndexOf(o.ToString()) > -1)
                    {
                        repeat_2_count += 2*(temp.Length - temp.Replace(o.ToString(), "").Length) / o.ToString().Length;
                        temp=temp.Replace(o.ToString(), ""); 
                    }
                }

                
                int repeat_3_count = 0;
                if (repeat_1_count + repeat_2_count == 0)
                {
                    repeat_3_count = 2*(temp.Length - temp.Replace(replace_3, "").Length) / K;
                    temp = temp.Replace(replace_3, "");
                    repeat_3_count += (temp.Length - temp.Replace(replace_1, "").Length) / K;
                    temp = temp.Replace(replace_1, "");
                }

                if (input.IndexOf("-") < 0)
                {
                    result += "Case #" + line.ToString() + ": 0\r\n";
                }
                else
                {
                    if (repeat_1_count + repeat_2_count + repeat_3_count == 0)
                    {
                        result += "Case #" + line.ToString() + ": IMPOSSIBLE\r\n";
                    }
                    else
                    {
                        if (temp.IndexOf("-")>-1)
                        {
                            result += "Case #" + line.ToString() + ": IMPOSSIBLE\r\n";
                        }
                        else
                        {
                            result += "Case #" + line.ToString() + ": " + (repeat_1_count + repeat_2_count+ repeat_3_count).ToString() + "\r\n";
                        }
                    }
                }

            }

            richTextBox1.Text += result.Trim();
            File.WriteAllText(@"C:\Users\lrjthinkpad\Desktop\b.txt", result.Trim());


        }
    }
}
