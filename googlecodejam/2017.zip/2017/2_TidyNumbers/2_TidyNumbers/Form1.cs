﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;



namespace _2_TidyNumbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string sort(string input)
        {
            string output = "";
            ArrayList al = new ArrayList();
            
            foreach(char c in input.ToArray())
            {
                al.Add(c.ToString());
            }

            al.Sort();

            foreach (object o in al)
            {
                output += o.ToString();
            }

            return output;
        }

        public string repeat(string input, int repeat)
        {
            string output = "";
            for (int i = 1; i <= repeat; i++)
            {
                output += input;
            }

            return output;
        }


        public Int64 check(Int64 input)
        {
            Int64 output = input;
            int pos = 0;
            string temp = input.ToString();

            for (int i = 1; i < temp.Length; i++)
            {
                if (Convert.ToInt32(temp.Substring(i, 1)) < Convert.ToInt32(temp.Substring(i - 1, 1)))
                {
                    pos = i;
                    break;
                }
            }
            string reBuild = "";
            for (int j = 0; j < pos; j++)
            {
                reBuild += temp.Substring(j, 1);
            }

            reBuild += repeat("0", temp.Length - pos);

            output = Convert.ToInt64(reBuild);

            return output;
        }



        private void button1_Click(object sender, EventArgs e)
        {

            string[] content = File.ReadAllLines(@"C:\Users\lrjthinkpad\Desktop\a.txt");
            string result = "";
            
            for (int line = 1; line < content.Count(); line++)
            {
                Int64 input = Convert.ToInt64(content[line].ToString()); 

                for (Int64 i = input; i > 0; i--)
                {

                    //if (i.ToString().IndexOf("0") > -1)
                    //{                        
                    //    continue; 
                    //}

                    if (i == Convert.ToInt64(this.sort(i.ToString())))
                    {
                        result += "Case #" + line.ToString() + ": " + i.ToString() + "\r\n";
                        break;
                    }
                    else
                    {
                        i = check(i);
                    }

                }
            }

            richTextBox1.Text = result; 

            File.WriteAllText(@"C:\Users\lrjthinkpad\Desktop\b.txt",result);
        }
    }
}
