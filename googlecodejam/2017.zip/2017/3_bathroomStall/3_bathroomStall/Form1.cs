﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace _3_bathroomStall
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int smaller(int a, int b)
        {
            return a > b ? b : a; 
        }

        public int larger(int a, int b)
        {
            return a > b ? a : b;
        }

        public ArrayList keys(Hashtable input, int value)
        {
            ArrayList output = new ArrayList();
            foreach (object o in input.Keys)
            {
                if ( (Int32)input[o] == value)
                {
                    output.Add(o.ToString()); 
                }
            }
            return output;
        }

        


        private void button1_Click(object sender, EventArgs e)
        {
            string[] slots = new string[1000];
            ArrayList distance = new ArrayList();
            Hashtable con_1 = new Hashtable();
            Hashtable con_2 = new Hashtable();
            for (int i = 0; i < slots.Length; i++)
            {
                slots[i] = "N"+(i+1).ToString()+ ':';
            }


            for (int i = 0; i<slots.Length; i++ )
            {
                //label1.Text = i.ToString();
                //label1.Refresh(); 
                int left = 0;
                int right = 0;
                for (int j = i ; j > 0; j--)
                {
                    if (slots[j].Substring(0, 1) == "N")
                    {
                        left++;
                    }
                    else
                    {
                        break; 
                    }

                }
                slots[i] += left.ToString();

                for (int k = i; k<slots.Length; k++)
                {
                    if (slots[k].Substring(0, 1) == "N")
                    {
                        right++;
                    }
                    else
                    {
                        break;
                    }

                }

                slots[i] += "-"+(right-1).ToString()+"|"+larger(left, right-1).ToString() + "^"+smaller(left, right-1).ToString();
                con_1[i] = smaller(left, right - 1);
                con_2[i] = larger(left, right - 1);                    
                
            }

            int maximal_in_minimal = 0;
            int maximal_in_maximal = 0;

            foreach (object o in con_1.Values)
            {
                if (Convert.ToInt32(o.ToString()) > maximal_in_minimal)
                {
                    maximal_in_minimal = Convert.ToInt32(o.ToString());
                }
            }


            foreach (object o in con_2.Values)
            {
                if (Convert.ToInt32(o.ToString()) > maximal_in_maximal)
                {
                    maximal_in_maximal = Convert.ToInt32(o.ToString());
                }
            }


            ArrayList al = this.keys(con_1, maximal_in_minimal);
            al.Sort();
            richTextBox1.Text += "Con1: " + al[0].ToString() + "\r\n"; //slot id

            al = this.keys(con_2, maximal_in_maximal);
            al.Sort();
            richTextBox1.Text += "Con2: " + al[0].ToString() + "\r\n";

            //foreach (string s in slots)
            //{
            //    richTextBox1.Text += s + "\r\n";
            //}

            


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
