﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions; 

namespace round1B_StableNeighbors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hashtable hs = new Hashtable();
            Hashtable color = new Hashtable();
            color[1] = "R";
            color[2] = "R+Y";
            color[3] = "Y";
            color[4] = "Y+B";
            color[5] = "B";
            color[6] = "R+B";
            string input = "6 2 0 2 0 2 0".Replace(" ", "");
            for (int i = 0; i < input.Length; i++)
            {
                if (i == 0)
                {
                    hs["Count"] = input[i];
                }
                else
                {
                    hs[i] = input[i];
                }
            }
            
        }
    }
}
