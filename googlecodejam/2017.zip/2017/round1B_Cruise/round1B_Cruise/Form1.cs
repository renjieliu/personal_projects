﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;


namespace round1B_Cruise
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public double max(ArrayList input)
        {
            double output = 0;
            foreach (object o in input)
            {
                if (Convert.ToDouble(o) > output)
                {
                    output = Convert.ToDouble(o);
                }
            }          


            return output; 
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string[] content = File.ReadAllLines(@"C:\Users\lrjthinkpad\Desktop\a.txt");
            int caseID = 0;
            int linesToRead = 0;
            int lineRead = 0;
            double distance = 0;
            int currentDistance = 0;
            ArrayList time = new ArrayList();
            for (int line = 1; line < content.Count(); line++)
            {
                if (linesToRead == 0)
                {
                    caseID++; 
                    linesToRead = Convert.ToInt32(content[line].Split(' ')[1]);
                    distance = Convert.ToInt32(content[line].Split(' ')[0]);
                }
                else
                {
                    lineRead++;
                    currentDistance = Convert.ToInt32(content[line].Split(' ')[0]);
                    time.Add( Convert.ToDouble( (distance-currentDistance) / Convert.ToInt32(content[line].Split(' ')[1])));
                    if (lineRead == linesToRead)
                    {
                        richTextBox1.Text += "Case #"+ caseID.ToString() + ": "+ Math.Round(distance / max(time),6).ToString() + "\r\n";
                        linesToRead = 0;
                        lineRead = 0;
                        distance = 0;
                        time = new ArrayList();
                        continue; 
                    }

                }   

            }

            File.WriteAllText(@"C:\Users\lrjthinkpad\Desktop\b.txt", richTextBox1.Text);
        }
    }
}
