﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace _1_PancakeFilpper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string flip(string input)
        {
            string output = "";
            foreach (char c in input.ToArray())
            {
                output += (c == '-' ? '+' : '-');
            }
            return output;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string[] content = File.ReadAllLines(@"C:\Users\lrjthinkpad\Desktop\a.txt");
            string result = "";
            for (int line = 1; line < content.Count(); line++)
            {
                string S = content[line].Split(' ')[0].ToString();
                int K = Convert.ToInt32(content[line].Split(' ')[1]);
                int count = 0;
                string temp = S;

                for (int i = 0; i <= S.Length - K; i++)
                {
                    int find_pos = temp.IndexOf('-');

                    if (find_pos < 0 || find_pos + K > temp.Length)
                    {
                        break; 
                    }
                    else
                    {
                        temp = flip(temp.Substring(find_pos, K)) + temp.Substring(find_pos + K);
                        count++;
                    }


                }
                if (temp.IndexOf('-') > -1)
                {
                    result += "Case #" + line.ToString() + ": IMPOSSIBLE\r\n";
                }
                else
                {
                    result += "Case #" + line.ToString() + ": "+ count.ToString()+"\r\n";
                }
            }

            richTextBox1.Text = result.ToString();
            File.WriteAllText(@"C:\Users\lrjthinkpad\Desktop\b.txt", result); 
        }
    }
}
