﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;

namespace LastWord
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public ArrayList dic = new ArrayList(); 

        public void P_all(string prev, string next)
        {
            if (next.Length == 1)
            {
                dic.Add(prev + next);
            }

            for (int i = 0; i < next.Length; i++)
            {
                string tempPrev = prev + next.Substring(i, 1);
                string tempNext = next.Remove(i, 1);
                P_all(tempPrev, tempNext);
            }

        }

        public ArrayList P(string input, int combo)
        {
            ArrayList output = new ArrayList();
            P_all("", input);
            dic.Sort();
            for (int i = 1; i < dic.Count; i++)
            {
                if (dic[i].ToString() != "" && dic[i - 1].ToString() != "" && dic[i].ToString().Substring(0, combo) == dic[i - 1].ToString().Substring(0, combo))
                {
                    dic[i] = dic[i].ToString() + "`";
                }
            }

            foreach (object o in dic)
            {
                if (o.ToString().IndexOf("`") < 0)
                {
                    output.Add(o.ToString().Substring(0, combo));
                }
            }

            return output;
        }

        

        public string sort(string input)
        {
            string output = "";
            ArrayList al = new ArrayList();
            foreach (char c in input)
            {
                al.Add(c);
            }

            al.Sort();

            foreach (object o in al)
            {
                output += o.ToString();
            }

            return output;
        }




        public ArrayList C(string input, int combo)
        {
            ArrayList output = new ArrayList();
            ArrayList temp = new ArrayList();

            foreach (object o in P(input, combo))
            {
                temp.Add(sort(o.ToString()));
            }

            temp.Sort();

            for (int i = 1; i < temp.Count; i++)
            {
                if (temp[i].ToString() != "" && temp[i - 1].ToString() != "" && temp[i].ToString().Substring(0, combo) == temp[i - 1].ToString().Substring(0, combo))
                {
                    temp[i] = temp[i].ToString() + "`";
                }
            }


            foreach (object o in temp)
            {
                if (o.ToString().IndexOf("`") < 0)
                {
                    output.Add(o.ToString());
                }
            }

            return output;


        }


        private void button1_Click(object sender, EventArgs e)
        {
            string[] content = File.ReadAllLines(@"C:\Users\lrjthinkpad\Desktop\a.txt");
            int line = 0;
            string result = ""; 
            for(int L = 1; L<content.Count(); L++)
            {
                string input = content[L].Trim();
                ArrayList al_even = new ArrayList();
                ArrayList al_odd = new ArrayList();
                ArrayList output = new ArrayList();
                for (int i = 0; i < input.Length; i++)
                {
                    if (i > 0 && i % 2 != 0)
                    {
                        al_odd.Clear();
                        foreach (object o in al_even)
                        {
                            if (String.Compare(input[i] + o.ToString(), o.ToString() + input[i]) >= 0)
                            {
                                al_odd.Add(input[i] + o.ToString());
                            }
                            else
                            {
                                al_odd.Add(o.ToString() + input[i]);
                            }
                        }
                    }

                    if (i > 0 && i % 2 == 0)
                    {
                        al_even.Clear();
                        foreach (object o in al_odd)
                        {
                            if (String.Compare(input[i] + o.ToString(), o.ToString() + input[i]) >= 0)
                            {
                                al_even.Add(input[i] + o.ToString());
                            }
                            else
                            {
                                al_even.Add(o.ToString() + input[i]);
                            }
                        }
                    }

                    else
                    {
                        al_even.Add(input[i].ToString());
                    }

                }

                foreach (object o in al_odd)
                {
                    if (o.ToString().Length == input.Length)
                    {
                        output.Add(o.ToString());
                    }
                }

                foreach (object o in al_even)
                {
                    if (o.ToString().Length == input.Length)
                    {
                        output.Add(o.ToString());
                    }
                }

                output.Sort();

                result += "Case #"+ L.ToString() +": "+output[output.Count - 1].ToString() + "\r\n";

                richTextBox1.Text = result;
                File.WriteAllText(@"C:\Users\lrjthinkpad\Desktop\b.txt", result);
                
            }

            MessageBox.Show("Done");




        }
    }
}
