﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;

namespace _2_pancakes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public string distinct(string s)
        {
            string output = s.Substring(0, 1);
            for (int i = 1; i < s.Length; i++)
            {
                if (s.Substring(i, 1) == s.Substring(i - 1, 1))
                {
                    continue;
                }
                else
                {
                    output += s.Substring(i, 1);
                }
            }
            return output;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] content = File.ReadAllLines(@"C:\Users\renjie.liu\Desktop\a.txt");
            string finalOutput = "";
            int caseCount = 0;
            foreach (string str in content)
            {
                caseCount++;
                if (caseCount > 1)
                {
                    if (str.Trim().Length > 0)
                    {
                        string current = this.distinct(str.Trim());
                        int lastIndex = (str.Substring(0, 1) == "-" ? 0 : 0);
                        finalOutput += "Case #" + (caseCount - 1).ToString() + ": " + (current.LastIndexOf('-') + 1 + lastIndex).ToString() + "\r\n";
                    }
                }

            }
            File.WriteAllText(@"C:\Users\renjie.liu\Desktop\b.txt", finalOutput);
        }
    }
}
