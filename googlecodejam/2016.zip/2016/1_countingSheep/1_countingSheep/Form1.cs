﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace _1_countingSheep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] file = File.ReadAllLines(@"D:\A-large-practice.in");
            string output = "";
            Hashtable hs = new Hashtable();
            int cse = 0;
            foreach (string s in file)
            {
                cse++;
                if (cse>1)
                {
                    int input = Convert.ToInt32(s.Trim());
                    if (Convert.ToInt32(s.Trim()) == 0)
                    {
                        output += "Case #" + (cse-1).ToString() + ": INSOMNIA\r\n";
                    }
                    else
                    {
                        for (int i = 1; i<=10000000 ; i++)
                        {
                            int temp = i * input;
                            for (int j = 0; j < temp.ToString().Length; j++)
                            {
                                if (hs[temp.ToString().Substring(j,1)] == null)
                                {
                                    hs[temp.ToString().Substring(j, 1)] = temp;
                                }
                                if (hs.Count == 10)
                                {
                                    output += "Case #" + (cse - 1).ToString() + ": "+temp.ToString()+"\r\n";
                                    hs = new Hashtable();
                                    i = 90000000; 
                                    break;
                                }
                            }

                        }
                    }


                }
                


            }

            File.WriteAllText("d:/output.txt", output.Trim());
            MessageBox.Show("Done!");

        }    
        
    }
}


