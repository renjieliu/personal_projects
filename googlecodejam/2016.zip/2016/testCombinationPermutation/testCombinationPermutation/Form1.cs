﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace testCombinationPermutation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public ArrayList dic = new ArrayList();

        public void P_all(string prev, string next)
        {
            if (next.Length == 1)
            {
                dic.Add(prev + next);
            }

            for (int i = 0; i < next.Length; i++)
            {
                string tempPrev = prev + next.Substring(i,1);
                string tempNext = next.Remove(i, 1);
                P_all(tempPrev, tempNext); 
            }            

        }

        public ArrayList P(string input, int combo)
        {
            ArrayList output = new ArrayList(); 
            P_all("", input);
            dic.Sort();
            for (int i = 1; i < dic.Count; i++)
            {
                if (dic[i].ToString()!="" && dic[i-1].ToString() != "" &&  dic[i].ToString().Substring(0,combo) == dic[i - 1].ToString().Substring(0, combo))
                {
                    dic.RemoveAt(i);
                }
            }

            foreach (object o in dic)
            {
                if (o.ToString().Length != 0)
                {
                    output.Add(o.ToString().Substring(0,combo)); 
                }
            }
            
            return output; 
        }





        public int f(int i)
        {
            if (i == 1)
            {
                return 1;
            }

            if (i == 2)
            {
                return 1;
            }
            else
            {
                return f(i - 1) + f(i - 2);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            ArrayList al = new ArrayList();
            al.Add("a"); al.Add("b"); al.Add("c"); al.Add("d"); al.Add("e");           

            foreach (object o in P("abcde",2))
            {
                richTextBox1.Text += o.ToString() + "\r\n";
            }
            
            //MessageBox.Show(f(30).ToString());
        }
    }
}
