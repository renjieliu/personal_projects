﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions; 


namespace _4_fractiles
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public ArrayList dic = new ArrayList();


        public void P_all(string prev, string next)
        {
            if (next.Length == 1)
            {
                dic.Add(prev + next);
            }

            for (int i = 0; i < next.Length; i++)
            {
                string tempPrev = prev + next.Substring(i, 1);
                string tempNext = next.Remove(i, 1);
                P_all(tempPrev, tempNext);
            }

        }

        public ArrayList P(string input, int combo)
        {
            ArrayList output = new ArrayList();
            P_all("", input);
            dic.Sort();
            for (int i = 1; i < dic.Count; i++)
            {
                if (dic[i].ToString() != "" && dic[i - 1].ToString() != "" && dic[i].ToString().Substring(0, combo) == dic[i - 1].ToString().Substring(0, combo))
                {
                    dic[i] = dic[i].ToString() + "`";
                }
            }

            foreach (object o in dic)
            {
                if (o.ToString().IndexOf("`") < 0)
                {
                    output.Add(o.ToString().Substring(0, combo));
                }
            }

            return output;
        }


      



        public string sort(string input)
        {
            string output = "";
            ArrayList al = new ArrayList();
            foreach (char c in input)
            {
                al.Add(c);
            }

            al.Sort();

            foreach (object o in al)
            {
                output += o.ToString();
            }

            return output;
        }

     


        public ArrayList C(string input, int combo)
        {
            ArrayList output = new ArrayList();
            ArrayList temp = new ArrayList();

            foreach (object o in P(input, combo))
            {
                temp.Add(sort(o.ToString()));
            }

            temp.Sort();

            for (int i = 1; i < temp.Count; i++)
            {
                if (temp[i].ToString() != "" && temp[i - 1].ToString() != "" && temp[i].ToString().Substring(0, combo) == temp[i - 1].ToString().Substring(0, combo))
                {
                    temp[i] = temp[i].ToString() + "`";
                }
            }


            foreach (object o in temp)
            {
                if (o.ToString().IndexOf("`") < 0)
                {
                    output.Add(o.ToString());
                }
            }

            return output;


        }

        public string reverse(string input)
        {
            string output = "";
            char[] c = input.ToArray();
            for (int i = c.Length; i > 0; i--)
            {
                output += c[i];
            }
            return output; 
        }

        public string getIt(string[] input, int pos)
        {
            string output = "";
            if (pos-1 >= input.Count())
            {
                output = input[(pos-1) % (input.Count()) ];
            }
            else
            {
                output = input[pos-1]; 
            }
            return output;
        }

        public ArrayList multiplyMatrix(ArrayList m1, ArrayList m2)
        {
            ArrayList output = new ArrayList();
            for (int i = 0; i< m1.Count; i++)
            {
                for (int j = 0; j < m2.Count; j++)
                {
                    output.Add(m1[i].ToString() + m2[j].ToString());            
                }                         
            }
           
            return output; 
        }

        public string substringFromRight(string input, int pos)
        {
            return input.Substring(input.Length-pos,1);
        } 



        public string repeat(string s, int count)
        {
            string output = "";
            for (int i = 1; i <= count; i++)
            {
                output += s; 
            }
            return output;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string result = "";
            richTextBox1.Text = ""; 
            ArrayList al_initial = new ArrayList();
            al_initial.Add("L");
            al_initial.Add("G");


            string[] content = File.ReadAllLines(@"C:\Users\lrjthinkpad\Desktop\a.txt");

            for (int w = 2; w <= content.Count(); w++)
            {
                label1.Text = (w - 1).ToString() + "/" + (content.Count()-1).ToString();
                label1.Refresh();
                ArrayList al = al_initial;
                string[] currentLine = content[w-1].Split(' ');
                int K = Convert.ToInt32(currentLine[0]);
                int C = Convert.ToInt32(currentLine[1]);
                int S = Convert.ToInt32(currentLine[2]);
                //richTextBox1.Text += "K:" + K.ToString() + "||| C:" + C.ToString() + "||| S:" + S.ToString() +"\r\n";
                for (int i = 2; i <= K; i++)
                {
                    al = multiplyMatrix(al, al_initial);
                }

                ArrayList text_result = new ArrayList();

                foreach (object o in al)
                {
                    this.dic = new ArrayList();
                    string x = o.ToString();
                    for (int i = 2; i <= C; i++) //compose the output string.
                    {
                        x = x.Replace("G", this.repeat("G", o.ToString().Length)).Replace("L", o.ToString());
                    }

                    text_result.Add(x);
                }

                int charCount = text_result[0].ToString().Length;

                string original = "";
                for (int i = 1; i <= charCount; i++)
                {
                    original += i.ToString();
                }

                ArrayList lkp_array = new ArrayList();

                for (int i = 1; i <= S; i++)
                {
                    foreach (object o in this.C(original, i))
                    {
                        lkp_array.Add(o.ToString());
                        //richTextBox1.Text += o.ToString() + "~~``\r\n"; 
                    }
                }

                int total = 0;

                foreach (object lkp in lkp_array) //each combination
                {

                    int same_count = 0;
                    foreach (object text in text_result) //try each line
                    {
                        int count = 0;
                        foreach (char c in lkp.ToString().ToArray()) //lookup each character of each line
                        {
                            if (substringFromRight(text.ToString(), Convert.ToInt32(c.ToString())) == "L")
                            {
                                count++;
                            }

                           //richTextBox1.Text += text.ToString() + "|" + lkp.ToString() + "|" + count.ToString() + "\r\n";
                        }
                        if (count == lkp.ToString().Length)
                        {
                            same_count++;//all the lookedup positions are Ls.
                        }
                    }

                    //richTextBox1.Text += "Same count:" + same_count.ToString() + "\r\n";
                    if (same_count == 1)
                    {
                        total++;
                        //richTextBox1.Text += Regex.Replace(lkp.ToString(), "(.)", "$1 ").Trim() + "\r\n";
                        result += "Case #" + (w-1).ToString() +": "+Regex.Replace(lkp.ToString(), "(.)", "$1 ").Trim() + "\r\n";
                        //MessageBox.Show(lkp.ToString());

                        break; //no need to find other combinations
                    }
                }

                if (total == 0)
                {
                    //richTextBox1.Text += "Case # : IMPOSSIBLE\r\n";
                    result += "Case #"+(w-1).ToString()+": IMPOSSIBLE\r\n";
                }
                

            }

            richTextBox1.Text += result; 
            File.WriteAllText(@"C:\Users\lrjthinkpad\Desktop\b.txt",result);


        }
    }
}
